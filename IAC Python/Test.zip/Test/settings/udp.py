UDP = {
    "SERVER_UDP_IPv4": '127.0.0.1',
    "CLIENT_UDP_IPv4": '127.0.0.0',
    "SERVER_PORT": 23
}